package com.decorator;

// ImportTaxDecorator class extends TaxDecorator
public class ImportTaxDecorator extends TaxDecorator {

    // Declare a private variable itemToDecorate of type Item
    private Item itemToDecorate;

    // Declare a final variable rate with a value of 0.05
    final double rate = 0.05;

    // Constructor that takes an Item object as a parameter
    public ImportTaxDecorator(Item itemtoDecorate) {
        // Call the constructor of the superclass TaxDecorator
        super(itemtoDecorate);
        // Assign the parameter itemtoDecorate to the private variable itemToDecorate
        this.itemToDecorate = itemtoDecorate;
    }

    // Override the getRate method from the superclass TaxDecorator
    @Override
    double getRate() {
        // Return the value of the rate variable
        return this.rate;
    }

    // Method to check if the item is imported
    public boolean isImported() {
        // Return the result of calling the isImported method on the itemToDecorate object
        return itemToDecorate.isImported();
    }

    // Method to get the name of the item
    public String getName() {
        // Return the result of calling the getName method on the itemToDecorate object
        return itemToDecorate.getName();
    }

    // Method to get the initial price of the item
    public double getInitPrice() {
        // Return the result of calling the getInitPrice method on the itemToDecorate object
        return itemToDecorate.getInitPrice();
    }

    // Override the hashCode method from the Object class
    @Override
    public int hashCode() {
        // Return the hash code of the name of the item
        return this.getName().hashCode();
    }

    // Override the equals method from the Object class
    @Override
    public boolean equals(Object obj) {
        // Check if the object is an instance of Item
        if (obj instanceof Item) {
            // Return true if the hash codes of the objects are equal
            return (((Item) obj).hashCode() == this.hashCode());
        }
        // Return false if the object is not an instance of Item
        return false;
    }

    // Method to check if the item is exempt from tax
    @Override
    public boolean isExempt() {
        // Return the result of calling the isExempt method on the itemToDecorate object
        return itemToDecorate.isExempt();
    }
}