package com.decorator;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ShoppingCart {

    private final Map<Item, Integer> itemMap = new HashMap<>();
    private final DecimalFormat df = new DecimalFormat("###.00");

    public void put(Item item, int count) {
        if (item.isImported()) item = new ImportTaxDecorator(item);
        if (!item.isExempt()) item = new SalesTaxDecorator(item);
        itemMap.merge(item, count, Integer::sum);
    }

    public void remove(Item item) {
        itemMap.remove(item);
    }

    public void clear() {
        itemMap.clear();
    }

    public Set<Item> getItems() {
        return itemMap.keySet();
    }

    public int getQuantity(Item item) {
        return itemMap.getOrDefault(item, 0);
    }

    public double getTaxtotal() {
        return itemMap.values().stream()
                .mapToDouble(count -> count * item.getPrice() - count * item.getInitPrice())
                .sum();
    }

    public double getTotal() {
        return itemMap.values().stream()
                .mapToDouble(count -> count * item.getPrice())
                .sum();
    }

    public void printOrderInput() {
        System.out.println("Order input:");
        itemMap.forEach((item, count) -> System.out.println(count + " " + item.getName() + " at " + df.format(item.getInitPrice())));
        System.out.println();
    }

    public void printOrderResults() {
        System.out.println("Order results:");
        itemMap.forEach((item, count) -> {
            double subTotal = count * item.getPrice();
            double subInitTotal = count * item.getInitPrice();
            double tax = subTotal - subInitTotal;
            System.out.println(count + " " + item.getName() + ": " + df.format(subTotal));
        });
        System.out.println("Sales Taxes: " + df.format(getTaxtotal()));
        System.out.println("Total: " + df.format(getTotal()));
        System.out.println();
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Proper Usage is: java -jar salestax filename(s)");
            System.out.println("example: java -jar salestax in1.txt in2.txt");
            System.exit(0);
        }
        for (String fileName : args) Util.getFromFile(fileName);
    }
}