package com.decorator;

public class WorkingItem implements Item {

    private String name;
    private boolean isImported;
    private boolean isExempt;
    private double initPrice;

    public WorkingItem(String name, double initPrice, boolean isImported, boolean isExempt) {
        this.name = name;
        this.initPrice = initPrice;
        this.isImported = isImported;
        this.isExempt = isExempt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isImported() {
        return isImported;
    }

    public void setImported(boolean isImported) {
        this.isImported = isImported;
    }

    public boolean isExempt() {
        return isExempt;
    }

    public void setExempt(boolean isExempt) {
        this.isExempt = isExempt;
    }

    public void setInitPrice(double price) {
        this.initPrice = price;
    }

    public double getInitPrice() {
        return this.initPrice;
    }

    @Override
    public int hashCode() {
        return name.hashCode() + Double.hashCode(initPrice);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        WorkingItem that = (WorkingItem) obj;
        return Double.compare(that.initPrice, initPrice) == 0 &&
                isImported == that.isImported &&
                isExempt == that.isExempt &&
                name.equals(that.name);
    }

    @Override
    public double getPrice() {
        return this.initPrice;
    }
}
T
You
Inline Comments
JDroid
JDroid AI
Copy to IDE
package com.decorator;

public class WorkingItem implements Item {

    private String name; // Declare a private String variable named 'name'
    private boolean isImported = false; // Declare a private boolean variable named 'isImported' and initialize it to false
    private boolean isExempt = false; // Declare a private boolean variable named 'isExempt' and initialize it to false
    private double initPrice; // Declare a private double variable named 'initPrice'

    public WorkingItem(String name,  double initPrice) { // Declare a constructor that takes a String and a double as parameters
        this.name = name; // Assign the value of the parameter 'name' to the 'name' variable
        this.initPrice = initPrice; // Assign the value of the parameter 'initPrice' to the 'initPrice' variable
    }

    public String getName() { // Declare a method named 'getName' that returns a String
        return name; // Return the value of the 'name' variable
    }

    public void setName(String name) { // Declare a method named 'setName' that takes a String as a parameter
        this.name = name; // Assign the value of the parameter 'name' to the 'name' variable
    }

    public boolean isImported() { // Declare a method named 'isImported' that returns a boolean
        return isImported; // Return the value of the 'isImported' variable
    }

    public void setImported(boolean isImported) { // Declare a method named 'setImported' that takes a boolean as a parameter
        this.isImported = isImported; // Assign the value of the parameter 'isImported' to the 'isImported' variable
    }

    public boolean isExempt() { // Declare a method named 'isExempt' that returns a boolean
        return isExempt; // Return the value of the 'isExempt' variable
    }

    public void setExempt(boolean isExempt) { // Declare a method named 'setExempt' that takes a boolean as a parameter
        this.isExempt = isExempt; // Assign the value of the parameter 'isExempt' to the 'isExempt' variable
    }

    public void setInitPrice(double price) { // Declare a method named 'setInitPrice' that takes a double as a parameter
        this.initPrice = price; // Assign the value of the parameter 'price' to the 'initPrice' variable
    }

    public double getInitPrice() { // Declare a method named 'getInitPrice' that returns a double
        return this.initPrice; // Return the value of the 'initPrice' variable
    }

    @Override
    public int hashCode() { // Declare a method named 'hashCode' that returns an int
        return name.hashCode() + new Integer((int) (initPrice * 100)); // Return the hash code of the 'name' variable plus the hash code of the 'initPrice' variable multiplied by 100
    }
    @Override
    public boolean equals(Object obj) { // Declare a method named 'equals' that takes an Object as a parameter
        if (obj == null) { // If the parameter 'obj' is null, return false
            return false;
        } else if (obj instanceof Item) { // If the parameter 'obj' is an instance of the 'Item' class, return true if the hash codes of the 'obj' and the current object are equal
            return (((Item) obj).hashCode() == this.hashCode());
        } else
            return false; // Otherwise, return false
    }

    @Override
    public double getPrice() { // Declare a method named 'getPrice' that returns a double
        return this.initPrice; // Return the value of the 'initPrice' variable
    }
}
