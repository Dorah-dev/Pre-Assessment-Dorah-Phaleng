package com.decorator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ItemParser {
	private static final String ITEM_DESCRIPTION_REGEX = "(\\d+)\\s((\\w+\\s)+)at\\s(\\d+.\\d+)";
	
	public static Item parser(String order) {
		Matcher m = parse(order);
		String name = m.group(2).trim();
		WorkingItem item = new WorkingItem(name, Double.valueOf(m.group(4)));
		if (name.contains("imported"))
			item.setImported(true);
		if (Util.isExempt(name))
			item.setExempt(true);
		return item;
	}

	public static int count (String order) {
		return Integer.valueOf(parse(order).group(1));
	}
	
	public static Matcher parse(String description) {
		Pattern pattern = Pattern.compile(ITEM_DESCRIPTION_REGEX);
		Matcher matcher = pattern.matcher(description);
		matcher.find();
		return matcher;
	}
	
	public static boolean matches(String description) {
		return Pattern.matches(ITEM_DESCRIPTION_REGEX, description);
	}
}
package com.decorator;

public class ImportTaxDecorator extends TaxDecorator {

    private Item itemToDecorate;

    final double rate = 0.05;

    public ImportTaxDecorator(Item itemtoDecorate) {
        super(itemtoDecorate);
        this.itemToDecorate = itemtoDecorate;
    }

    @Override
    double getRate() {
        return this.rate;
    }

    public boolean isImported() {
        return itemToDecorate.isImported();
    }

    public String getName() {
        return itemToDecorate.getName();
    }

    public double getInitPrice() {
        return itemToDecorate.getInitPrice();
    }

    @Override
    public int hashCode() {
        return this.getName().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Item) {
            return (((Item) obj).hashCode() == this.hashCode());
        }
        return false;
    }

    @Override
    public boolean isExempt() {
        return itemToDecorate.isExempt();
    }
}
