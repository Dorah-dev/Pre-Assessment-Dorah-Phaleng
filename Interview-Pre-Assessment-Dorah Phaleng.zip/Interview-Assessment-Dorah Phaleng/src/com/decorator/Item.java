package com.decorator;

public interface Item {

    String getName();

    double getInitPrice();

    boolean isImported();

    boolean isExempt();

    default double getPrice() {
        return getInitPrice() + (isImported() ? 0.1 : 0) + (isExempt() ? 0 : 0.05);
    }
}
