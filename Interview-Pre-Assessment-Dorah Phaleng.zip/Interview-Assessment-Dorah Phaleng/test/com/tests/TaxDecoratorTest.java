package com.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import com.decorator.ImportTaxDecorator;
import com.decorator.Item;
import com.decorator.SalesTaxDecorator;
import com.decorator.WorkingItem;

public class TaxDecoratorTest {

    @Test
    public void testGetPrice() {
        // Create a new WorkingItem object with name "Test" and price 100.00
        Item item = new WorkingItem("Test",  100.00);
        
        // Check if the name of the item is "Test"
        assertEquals(item.getName(),  "Test");
        
        // Print the price of the item
        System.out.println(item.getPrice());
        
        // Check if the price of the item is 100.00
        assertTrue(Math.abs((item.getPrice() - 100.00)) < 0.001);
        
        // Decorate the item with ImportTaxDecorator
        item = new ImportTaxDecorator(item);
        
        // Print the price of the decorated item
        System.out.println(item.getPrice());
        
        // Check if the price of the decorated item is 105.00
        assertTrue(Math.abs((item.getPrice() - 105.00)) < 0.001);
        
        // Decorate the item with SalesTaxDecorator
        item = new SalesTaxDecorator(item);
        
        // Print the price of the decorated item
        System.out.println(item.getPrice());
        
        // Check if the price of the decorated item is 115.00
        assertTrue(Math.abs((item.getPrice() - 115.00)) < 0.001);
        
        // Print the initial price of the item
        System.out.println(item.getInitPrice());
        
        // Check if the initial price of the item is 100.00
        assertTrue(Math.abs((item.getInitPrice() - 100.00)) < 0.001);
    }

}