package com.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import com.decorator.Util;

public class UtilTest {

    // Test the nearest5Percent method
    @Test
    public void testNearest5Percent() {
        // Check if the absolute difference between the result and the expected value is less than 0.0001
        assertTrue(Math.abs((Util.nearest5Percent(1.03)) - 1.05) < 0.0001);
    }

    // Test the roundPrice method
    @Test
    public void testRoundPrice() {
        // Check if the absolute difference between the result and the expected value is greater than 0.008
        assertTrue(Math.abs((Util.roundPrice(10.125456) - 10.12)) > 0.008);
    }

    // Test the isExempt method
    @Test
    public void testIsExempt() {
        // Check if the result is true
        assertTrue(Util.isExempt("chocolate bar"));
    }

}
