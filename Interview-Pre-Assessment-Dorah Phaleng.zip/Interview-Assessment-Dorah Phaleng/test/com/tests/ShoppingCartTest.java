package com.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import com.decorator.ItemParser;
import com.decorator.ShoppingCart;

public class ShoppingCartTest {

    @Test
    public void testInput() {
        // Create a new instance of ShoppingCart
        ShoppingCart sc = new ShoppingCart();
        
        // Add items to the shopping cart
        sc.put(ItemParser.parser("1 book at 12.49"),  ItemParser.count("1 book at 12.49"));
        sc.put(ItemParser.parser("1 music CD at 14.99"),  ItemParser.count("1 music CD at 14.99"));
        sc.put(ItemParser.parser("1 chocolate bar at 0.85"),  ItemParser.count("1 chocolate bar at 0.85"));
        
        // Print the order input
        sc.printOrderInput();
        
        // Print the order results
        sc.printOrderResults();
        
        // Assert that the tax total is within a small tolerance of 1.50
        assertTrue (Math.abs((sc.getTaxtotal() - 1.50)) < 0.001);
        
        // Assert that the total is within a small tolerance of 29.83
        assertTrue (Math.abs((sc.getTotal() - 29.83)) < 0.001);
    }

    @Test
    public void testInputMultipleItems() {
        // Create a new instance of ShoppingCart
        ShoppingCart sc = new ShoppingCart();
        
        // Add multiple items to the shopping cart
        sc.put(ItemParser.parser("2 book at 12.49"),  ItemParser.count("2 book at 12.49"));
        sc.put(ItemParser.parser("2 music CD at 14.99"),  ItemParser.count("2 music CD at 14.99"));
        sc.put(ItemParser.parser("2 chocolate bar at 0.85"),  ItemParser.count("2 chocolate bar at 0.85"));
        
        // Print the order input
        sc.printOrderInput();
        
        // Print the order results
        sc.printOrderResults();
    }

    @Test
    public void testDoubleEntry() {
        // Create a new instance of ShoppingCart
        ShoppingCart sc = new ShoppingCart();
        
        // Add a double entry of books to the shopping cart
        sc.put(ItemParser.parser("2 book at 10.00"),  ItemParser.count("2 book at 10.00"));
        sc.put(ItemParser.parser("2 book at 100.00"),  ItemParser.count("2 book at 100.00"));
        
        // Print the order input
        sc.printOrderInput();
        
        // Print the order results
        sc.printOrderResults();
        
        // Assert that the number of items in the shopping cart is 2
        assertTrue(sc.getItems().size() == 2);
    }

    @Test
    public void testDoubEntry() {
        // Create a new instance of ShoppingCart
        ShoppingCart sc = new ShoppingCart();
        
        // Add a double entry of books to the shopping cart
        sc.put(ItemParser.parser("2 book at 10.00"),  ItemParser.count("2 book at 10.00"));
        sc.put(ItemParser.parser("2 book at 10.00"),  ItemParser.count("2 book at 10.00"));
        
        // Print the order input
        sc.printOrderInput();
        
        // Print the order results
        sc.printOrderResults();
        
        // Assert that the number of items in the shopping cart is 1
        assertTrue(sc.getItems().size() == 1);
    }
}
